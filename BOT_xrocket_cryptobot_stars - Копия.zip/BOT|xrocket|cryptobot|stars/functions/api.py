"""
Клиент VPN API.

Base URL и токен задаются в .env (API_URL, API_TOKEN).
Авторизация: заголовок  Authorization: Bearer <token>

Единый формат ответа:
    успех   -> {"ok": true,  "data": {...}}
    ошибка  -> {"ok": false, "error": {"code": "...", "message": "..."}}
"""

import os
import asyncio
import logging
import aiohttp

BASE_URL = os.getenv("API_URL", "https://proxy.killa.cc/api/v1")
API_TOKEN = os.getenv("API_TOKEN", "")

# Коды ошибок, при которых имеет смысл повторить запрос
_RETRYABLE = {"provider_error", "internal_error"}


def _headers() -> dict:
    return {
        "Authorization": f"Bearer {API_TOKEN}",
        "Content-Type": "application/json",
    }


async def _request(method: str, path: str, *, params: dict = None,
                   json_body: dict = None, retries: int = 2) -> dict:
    """
    Низкоуровневый запрос к API. Всегда возвращает dict формата
    ({"ok": bool, ...}). Сетевые сбои оборачиваются в {"ok": false, "error": ...}.
    """
    url = f"{BASE_URL}{path}"
    attempt = 0
    while True:
        attempt += 1
        try:
            timeout = aiohttp.ClientTimeout(total=30)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.request(
                    method, url, headers=_headers(), params=params, json=json_body
                ) as resp:
                    try:
                        data = await resp.json()
                    except Exception:
                        text = await resp.text()
                        data = {"ok": False, "error": {"code": "bad_response",
                                                       "message": text[:200]}}

                    # Ретрай при 5xx / provider_error
                    code = (data.get("error") or {}).get("code")
                    if (resp.status >= 500 or code in _RETRYABLE) and attempt <= retries:
                        await asyncio.sleep(min(10 * attempt, 30))
                        continue
                    return data
        except (aiohttp.ClientError, asyncio.TimeoutError) as e:
            logging.error(f"API сетевой сбой ({path}): {e}")
            if attempt <= retries:
                await asyncio.sleep(5 * attempt)
                continue
            return {"ok": False, "error": {"code": "network_error", "message": str(e)}}


# ─────────────────────────────  VPN  ─────────────────────────────

async def get_quote() -> dict:
    """GET /vpn/quote — тарифы по месяцам и по пробному тарифу."""
    return await _request("GET", "/vpn/quote")


async def buy_vpn(period_months: int) -> dict:
    """
    POST /vpn/buy — купить подписку на period_months.
    В data: uuid, subscriptionUrl, expireAt, expireAt_date, price_rub.
    """
    return await _request("POST", "/vpn/buy", json_body={"period_months": period_months})


async def buy_trial() -> dict:
    """POST /vpn/buy с plan=trial — платный пробный тариф."""
    return await _request("POST", "/vpn/buy", json_body={"plan": "trial"})


async def renew_vpn(uuid: str, period_months: int) -> dict:
    """POST /vpn/renew — продлить существующую подписку по uuid."""
    return await _request(
        "POST", "/vpn/renew",
        json_body={"uuid": uuid, "period_months": period_months},
    )


async def delete_vpn(uuid: str) -> dict:
    """POST /vpn/delete — удалить подписку."""
    return await _request("POST", "/vpn/delete", json_body={"uuid": uuid})


async def get_vpn_info(uuid: str) -> dict:
    """GET /vpn/info?uuid= — статус, срок, ссылка, лимиты."""
    return await _request("GET", "/vpn/info", params={"uuid": uuid})


async def get_balance() -> dict:
    """GET /balance — баланс в рублях."""
    return await _request("GET", "/balance")


# Обратная совместимость по имени
async def get_vpn_trial() -> dict:
    return await buy_trial()
