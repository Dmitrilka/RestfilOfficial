"""Утилиты интерфейса."""


def primary(kb: dict) -> dict:
    """
    Проставляет style="primary" всем кнопкам инлайн-клавиатуры.
    Единый стиль оформления кнопок по всему боту.
    """
    if isinstance(kb, dict):
        for row in kb.get("inline_keyboard", []):
            for btn in row:
                if isinstance(btn, dict):
                    btn["style"] = "primary"
    return kb
