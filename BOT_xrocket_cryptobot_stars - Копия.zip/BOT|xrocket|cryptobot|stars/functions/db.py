"""
Работа с базой данных (SQLite через aiosqlite).

Таблицы:
- users              — пользователи бота + реферальная система
- vpn_subscriptions  — выданные VPN-подписки (uuid из API)
- settings           — настройки бота (цены, тумблеры платёжек, курсы)
- payments           — созданные счета всех платёжных систем (для проверки статуса)
"""

import os
import logging
import aiosqlite
from datetime import datetime

DB_NAME = os.getenv("DB_NAME", "database.sqlite")

# Начисление звёзд за реферала (и приглашённому, и пригласившему)
REFERRAL_STARS = 15

# Значения настроек по умолчанию. Базовые цены совпадают с тарифами API
# (GET /vpn/quote), наценка 100% — итоговая цена для пользователя.
DEFAULT_SETTINGS = {
    "vpn_enabled": "1",         # автоматическая выдача VPN включена
    "stars_enabled": "1",       # оплата через Telegram Stars
    "platega_enabled": "1",     # оплата картой (Platega)
    "cryptobot_enabled": "1",   # оплата CryptoBot
    "xrocket_enabled": "1",     # оплата xRocket
    "stars_rate": "2",          # 1 звезда = 2 ₽
    "usd_rub_rate": "100",      # курс USD/USDT → RUB (для xRocket)
    "price_1_base": "200",
    "price_3_base": "500",
    "price_6_base": "900",
    "price_12_base": "1500",
    "price_1_markup": "100",
    "price_3_markup": "100",
    "price_6_markup": "100",
    "price_12_markup": "100",
    "broadcast_interval": "10800",  # интервал авто-рассылки, секунды
}


async def init_db():
    """Создаёт таблицы (если их нет) и заполняет настройки по умолчанию."""
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                user_id      INTEGER PRIMARY KEY,
                username     TEXT,
                full_name    TEXT,
                referred_by  INTEGER,
                stars_earned INTEGER DEFAULT 0,
                earned_rub   REAL    DEFAULT 0,
                created_at   TEXT
            )
            """
        )
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS vpn_subscriptions (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id          INTEGER,
                uuid             TEXT,
                subscription_url TEXT,
                expire_at        TEXT,
                expire_at_date   TEXT,
                created_at       TEXT
            )
            """
        )
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS settings (
                key   TEXT PRIMARY KEY,
                value TEXT
            )
            """
        )
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS payments (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id     INTEGER,
                method      TEXT,
                months      INTEGER,
                amount_rub  REAL,
                invoice_id  TEXT,
                status      TEXT DEFAULT 'pending',
                created_at  TEXT
            )
            """
        )
        # Настройки по умолчанию (не перезаписываем уже существующие)
        for key, value in DEFAULT_SETTINGS.items():
            await db.execute(
                "INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)",
                (key, value),
            )
        await db.commit()
    logging.info("База данных инициализирована.")


# ─────────────────────────────  ПОЛЬЗОВАТЕЛИ  ─────────────────────────────

async def add_user(user_id: int, username: str, full_name: str, referred_by: int = None) -> bool:
    """
    Регистрирует пользователя при /start. Возвращает True, если пользователь
    новый (создан впервые). При наличии валидного реферера начисляет звёзды
    обоим — приглашённому и пригласившему.
    """
    try:
        async with aiosqlite.connect(DB_NAME) as db:
            cur = await db.execute("SELECT 1 FROM users WHERE user_id = ?", (user_id,))
            exists = await cur.fetchone()
            if exists:
                # Обновим username/full_name на случай изменений
                await db.execute(
                    "UPDATE users SET username = ?, full_name = ? WHERE user_id = ?",
                    (username, full_name, user_id),
                )
                await db.commit()
                return False

            # Не позволяем указать реферером несуществующего пользователя
            valid_ref = None
            if referred_by:
                cur = await db.execute("SELECT 1 FROM users WHERE user_id = ?", (referred_by,))
                if await cur.fetchone():
                    valid_ref = referred_by

            await db.execute(
                """
                INSERT INTO users (user_id, username, full_name, referred_by, stars_earned, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    user_id,
                    username,
                    full_name,
                    valid_ref,
                    REFERRAL_STARS if valid_ref else 0,
                    datetime.now().isoformat(),
                ),
            )
            if valid_ref:
                # Пригласившему тоже +15 звёзд
                await db.execute(
                    "UPDATE users SET stars_earned = stars_earned + ? WHERE user_id = ?",
                    (REFERRAL_STARS, valid_ref),
                )
            await db.commit()
            return True
    except Exception as e:
        logging.error(f"Ошибка при добавлении пользователя: {e}")
        return False


async def get_all_users() -> list:
    """Список всех user_id (для рассылки)."""
    try:
        async with aiosqlite.connect(DB_NAME) as db:
            cur = await db.execute("SELECT user_id FROM users")
            rows = await cur.fetchall()
            return [r[0] for r in rows]
    except Exception as e:
        logging.error(f"Ошибка get_all_users: {e}")
        return []


async def get_user_stats(user_id: int):
    """Возвращает кортеж (кол-во рефералов, заработано звёзд, заработано рублей)."""
    try:
        async with aiosqlite.connect(DB_NAME) as db:
            cur = await db.execute(
                "SELECT COUNT(*) FROM users WHERE referred_by = ?", (user_id,)
            )
            referrals = (await cur.fetchone())[0]

            cur = await db.execute(
                "SELECT stars_earned, earned_rub FROM users WHERE user_id = ?", (user_id,)
            )
            row = await cur.fetchone()
            stars = row[0] if row else 0
            earned_rub = row[1] if row else 0.0
            return (referrals, stars, earned_rub)
    except Exception as e:
        logging.error(f"Ошибка get_user_stats: {e}")
        return (0, 0, 0.0)


async def get_referrer(user_id: int):
    """Возвращает user_id пригласившего или None."""
    try:
        async with aiosqlite.connect(DB_NAME) as db:
            cur = await db.execute(
                "SELECT referred_by FROM users WHERE user_id = ?", (user_id,)
            )
            row = await cur.fetchone()
            return row[0] if row and row[0] else None
    except Exception as e:
        logging.error(f"Ошибка get_referrer: {e}")
        return None


async def add_referral_earning(referrer_id: int, amount_rub: float):
    """Начисляет пригласившему процент с покупки (в рублях)."""
    try:
        async with aiosqlite.connect(DB_NAME) as db:
            await db.execute(
                "UPDATE users SET earned_rub = earned_rub + ? WHERE user_id = ?",
                (amount_rub, referrer_id),
            )
            await db.commit()
    except Exception as e:
        logging.error(f"Ошибка add_referral_earning: {e}")


# ─────────────────────────────  ПОДПИСКИ  ─────────────────────────────

async def add_vpn_subscription(user_id: int, uuid: str, expire_at: str,
                               subscription_url: str, expire_at_date: str = None):
    """Сохраняет выданную подписку."""
    try:
        async with aiosqlite.connect(DB_NAME) as db:
            await db.execute(
                """
                INSERT INTO vpn_subscriptions
                    (user_id, uuid, subscription_url, expire_at, expire_at_date, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (user_id, uuid, subscription_url, expire_at, expire_at_date,
                 datetime.now().isoformat()),
            )
            await db.commit()
    except Exception as e:
        logging.error(f"Ошибка add_vpn_subscription: {e}")


async def update_vpn_subscription(uuid: str, expire_at: str, subscription_url: str,
                                  expire_at_date: str = None):
    """Обновляет подписку после продления."""
    try:
        async with aiosqlite.connect(DB_NAME) as db:
            await db.execute(
                """
                UPDATE vpn_subscriptions
                SET expire_at = ?, subscription_url = ?, expire_at_date = ?
                WHERE uuid = ?
                """,
                (expire_at, subscription_url, expire_at_date, uuid),
            )
            await db.commit()
    except Exception as e:
        logging.error(f"Ошибка update_vpn_subscription: {e}")


async def get_user_subscriptions(user_id: int) -> list:
    """Все подписки пользователя (свежие сверху) в виде списка dict."""
    try:
        async with aiosqlite.connect(DB_NAME) as db:
            db.row_factory = aiosqlite.Row
            cur = await db.execute(
                """
                SELECT uuid, subscription_url, expire_at, expire_at_date
                FROM vpn_subscriptions WHERE user_id = ?
                ORDER BY id DESC
                """,
                (user_id,),
            )
            rows = await cur.fetchall()
            return [dict(r) for r in rows]
    except Exception as e:
        logging.error(f"Ошибка get_user_subscriptions: {e}")
        return []


async def get_active_subscription(user_id: int):
    """
    Возвращает последнюю не истёкшую подписку (dict) или None.
    Используется для продления (renew) вместо покупки новой.
    """
    subs = await get_user_subscriptions(user_id)
    now = datetime.now()
    for s in subs:
        expire = s.get("expire_at")
        if not expire:
            continue
        try:
            dt = datetime.fromisoformat(expire.replace("Z", "+00:00")).replace(tzinfo=None)
            if dt > now:
                return s
        except Exception:
            continue
    return None


async def get_subscription_url(user_id: int):
    """Ссылка на последнюю подписку пользователя (для отображения)."""
    subs = await get_user_subscriptions(user_id)
    return subs[0]["subscription_url"] if subs else None


async def has_active_subscription(user_id: int) -> bool:
    """Есть ли у пользователя хотя бы одна активная (не истёкшая) подписка."""
    return await get_active_subscription(user_id) is not None


# ─────────────────────────────  НАСТРОЙКИ  ─────────────────────────────

async def get_setting(key: str, default=None):
    """Читает значение настройки (строкой). Возвращает default, если нет."""
    try:
        async with aiosqlite.connect(DB_NAME) as db:
            cur = await db.execute("SELECT value FROM settings WHERE key = ?", (key,))
            row = await cur.fetchone()
            return row[0] if row else default
    except Exception as e:
        logging.error(f"Ошибка get_setting({key}): {e}")
        return default


async def set_setting(key: str, value):
    """Записывает/обновляет настройку."""
    try:
        async with aiosqlite.connect(DB_NAME) as db:
            await db.execute(
                "INSERT INTO settings (key, value) VALUES (?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                (key, str(value)),
            )
            await db.commit()
    except Exception as e:
        logging.error(f"Ошибка set_setting({key}): {e}")


async def is_vpn_enabled() -> bool:
    """Включена ли автоматическая выдача VPN."""
    return (await get_setting("vpn_enabled", "1")) == "1"


# ─────────────────────────────  ПЛАТЕЖИ  ─────────────────────────────

async def add_payment(user_id: int, method: str, months: int, amount_rub: float,
                      invoice_id: str) -> int:
    """Создаёт запись о счёте, возвращает её id."""
    try:
        async with aiosqlite.connect(DB_NAME) as db:
            cur = await db.execute(
                """
                INSERT INTO payments (user_id, method, months, amount_rub, invoice_id, status, created_at)
                VALUES (?, ?, ?, ?, ?, 'pending', ?)
                """,
                (user_id, method, months, amount_rub, str(invoice_id),
                 datetime.now().isoformat()),
            )
            await db.commit()
            return cur.lastrowid
    except Exception as e:
        logging.error(f"Ошибка add_payment: {e}")
        return 0


async def get_payment(invoice_id: str, method: str = None):
    """Возвращает счёт по invoice_id (и опц. методу) как dict или None."""
    try:
        async with aiosqlite.connect(DB_NAME) as db:
            db.row_factory = aiosqlite.Row
            if method:
                cur = await db.execute(
                    "SELECT * FROM payments WHERE invoice_id = ? AND method = ?",
                    (str(invoice_id), method),
                )
            else:
                cur = await db.execute(
                    "SELECT * FROM payments WHERE invoice_id = ?", (str(invoice_id),)
                )
            row = await cur.fetchone()
            return dict(row) if row else None
    except Exception as e:
        logging.error(f"Ошибка get_payment: {e}")
        return None


async def mark_payment_paid(invoice_id: str) -> bool:
    """
    Помечает счёт оплаченным. Возвращает True, только если счёт был в статусе
    pending (защита от повторной выдачи VPN при двойной проверке).
    """
    try:
        async with aiosqlite.connect(DB_NAME) as db:
            cur = await db.execute(
                "UPDATE payments SET status = 'paid' WHERE invoice_id = ? AND status = 'pending'",
                (str(invoice_id),),
            )
            await db.commit()
            return cur.rowcount > 0
    except Exception as e:
        logging.error(f"Ошибка mark_payment_paid: {e}")
        return False


async def get_pending_payments(method: str = None) -> list:
    """Список неоплаченных счетов (опц. по методу) как список dict."""
    try:
        async with aiosqlite.connect(DB_NAME) as db:
            db.row_factory = aiosqlite.Row
            if method:
                cur = await db.execute(
                    "SELECT * FROM payments WHERE status = 'pending' AND method = ?",
                    (method,),
                )
            else:
                cur = await db.execute("SELECT * FROM payments WHERE status = 'pending'")
            rows = await cur.fetchall()
            return [dict(r) for r in rows]
    except Exception as e:
        logging.error(f"Ошибка get_pending_payments: {e}")
        return []
