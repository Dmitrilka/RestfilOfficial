"""
Личный кабинет пользователя (callback "my_profile").
Показывает активные подписки: статус, сколько осталось дней, ссылку.
"""

from datetime import datetime
from aiogram import Router, types, F
from aiogram.exceptions import TelegramBadRequest

from functions import db
from functions.ui import primary

router = Router()


def _fmt_subscription(sub: dict) -> str:
    """Форматирует одну подписку для вывода."""
    expire = sub.get("expire_at")
    days_left = None
    active = False
    if expire:
        try:
            dt = datetime.fromisoformat(expire.replace("Z", "+00:00")).replace(tzinfo=None)
            delta = (dt - datetime.now()).days
            days_left = max(0, delta)
            active = dt > datetime.now()
        except Exception:
            pass

    status = "🟢 Активна" if active else "🔴 Истекла"
    lines = [
        "─────────────────",
        f"Статус: {status}",
    ]
    if days_left is not None:
        lines.append(f"Осталось дней: {days_left}")
    if sub.get("expire_at_date"):
        lines.append(f"До: {sub['expire_at_date']}")
    if sub.get("subscription_url"):
        lines.append(f"Ссылка: <code>{sub['subscription_url']}</code>")
    return "\n".join(lines)


@router.callback_query(F.data == "my_profile")
async def process_profile(callback_query: types.CallbackQuery):
    user_id = callback_query.from_user.id
    subs = await db.get_user_subscriptions(user_id)

    if not subs:
        text = (
            "<b>👤 Мой кабинет</b>\n\n"
            "У вас пока нет подписок.\n"
            "Нажмите «Получить ВПН», чтобы оформить доступ."
        )
        kb = {"inline_keyboard": [
            [{"text": "🌐 Получить ВПН", "callback_data": "get_vpn"}],
            [{"text": "⬅️ Назад в меню", "callback_data": "back_to_main"}],
        ]}
    else:
        body = "\n".join(_fmt_subscription(s) for s in subs)
        text = f"<b>👤 Мой кабинет</b>\n\n<b>Ваши подписки:</b>\n{body}\n─────────────────"
        kb = {"inline_keyboard": [
            [{"text": "🔄 Продлить / купить", "callback_data": "get_vpn"}],
            [{"text": "⬅️ Назад в меню", "callback_data": "back_to_main"}],
        ]}

    kb = primary(kb)
    try:
        await callback_query.message.edit_text(text, reply_markup=kb,
                                               disable_web_page_preview=True)
    except TelegramBadRequest:
        await callback_query.message.answer(text, reply_markup=kb,
                                            disable_web_page_preview=True)
    await callback_query.answer()
