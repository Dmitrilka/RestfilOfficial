"""
Раздел «Информация» — постоянный доступ к юридическим документам и поддержке.
Открывается кнопкой «ℹ️ Информация» в главном меню и командой /info.

Тексты/ссылки берутся из .env:
- PRIVACY_URL      — политика конфиденциальности
- TERMS_URL        — пользовательское соглашение
- SUPPORT_USERNAME — юзернейм поддержки (без @)
- SUPPORT_EMAIL    — почта поддержки
"""

import os
from aiogram import Router, types, F
from aiogram.filters import Command
from aiogram.exceptions import TelegramBadRequest

from functions.ui import primary

router = Router()

PRIVACY_URL = os.getenv("PRIVACY_URL", "")
TERMS_URL = os.getenv("TERMS_URL", "")
SUPPORT_USERNAME = os.getenv("SUPPORT_USERNAME", "").lstrip("@")
SUPPORT_EMAIL = os.getenv("SUPPORT_EMAIL", "")


def _info_text() -> str:
    lines = [
        "<b>ℹ️ Информация</b>\n",
        "Здесь собраны юридические документы сервиса и контакты поддержки.\n",
        "<b>🛟 Поддержка:</b>",
    ]
    if SUPPORT_USERNAME:
        lines.append(f"• Telegram: @{SUPPORT_USERNAME}")
    if SUPPORT_EMAIL:
        lines.append(f"• Email: {SUPPORT_EMAIL}")
    if not SUPPORT_USERNAME and not SUPPORT_EMAIL:
        lines.append("• Контакты поддержки уточняются.")
    lines.append("\nПо всем вопросам оплаты и работы сервиса обращайтесь в поддержку.")
    return "\n".join(lines)


def _info_keyboard() -> dict:
    rows = []
    if PRIVACY_URL:
        rows.append([{"text": "📄 Политика конфиденциальности", "url": PRIVACY_URL}])
    if TERMS_URL:
        rows.append([{"text": "📄 Пользовательское соглашение", "url": TERMS_URL}])
    if SUPPORT_USERNAME:
        rows.append([{"text": "🛟 Написать в поддержку", "url": f"https://t.me/{SUPPORT_USERNAME}"}])
    rows.append([{"text": "⬅️ Назад в меню", "callback_data": "back_to_main"}])
    return primary({"inline_keyboard": rows})


@router.message(Command("info"))
async def cmd_info(message: types.Message):
    await message.answer(_info_text(), reply_markup=_info_keyboard(),
                         disable_web_page_preview=True)


@router.callback_query(F.data == "info")
async def process_info(callback_query: types.CallbackQuery):
    try:
        await callback_query.message.edit_text(
            _info_text(), reply_markup=_info_keyboard(), disable_web_page_preview=True
        )
    except TelegramBadRequest:
        await callback_query.message.answer(
            _info_text(), reply_markup=_info_keyboard(), disable_web_page_preview=True
        )
    await callback_query.answer()
