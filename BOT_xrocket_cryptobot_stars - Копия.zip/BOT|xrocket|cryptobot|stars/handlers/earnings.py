import logging
import os
import urllib.parse

from aiogram import Router, types, Bot, F
from aiogram.exceptions import TelegramBadRequest
from functions.db import get_user_stats, has_active_subscription
from functions.ui import primary

router = Router()

@router.callback_query(F.data == "earnings")
async def process_earnings(callback_query: types.CallbackQuery, bot: Bot):
    """
    Обработчик меню заработка. Показывает статистику и реферальную ссылку.
    """
    user_id = callback_query.from_user.id
    admin_username = os.getenv("ADMIN_USERNAME", "").lstrip("@")
    support_username = os.getenv("SUPPORT_USERNAME", "").lstrip("@")
    contact_username = admin_username or support_username
    
    # Получаем статс из БД
    stats = await get_user_stats(user_id)
    referrals_count = stats[0] if stats else 0
    stars_earned = stats[1] if stats else 0
    earned_rub = stats[2] if stats else 0.0
    
    # Генерируем реф ссылку
    bot_info = await bot.get_me()
    ref_link = f"https://t.me/{bot_info.username}?start={user_id}"
    
    # Текст для шеринга
    share_text = "👆 Получи бесплатный VPN и 15 ⭐️ звезд 👆"
    encoded_text = urllib.parse.quote(share_text)
    # Параметр url ставим в конец, чтобы он шел после текста
    share_url = f"https://t.me/share/url?url={ref_link}&text={encoded_text}"
    
    text = (
        "<b>👨‍👩‍👧‍👦 Реферальная система</b>\n\n"
        "Вы получаете <b>50%</b> с каждой покупки приглашённого пользователя.\n\n"
        "<blockquote>20 оплат по 1 месяцу = 20 x 350 ₽ x 50% = 3500 ₽ в месяц.</blockquote>\n\n"
        "За каждого приглашённого по вашей ссылке вы и ваш друг получаете <b>15 ⭐️</b>.\n\n"
        f"<b>🔗 Ссылка:</b>  <code>{ref_link}</code>\n"
        "<b>⚖️ Ставка:</b>  <code>50%</code> \n\n"
        f"👤 <b>Приглашено: </b> <code>{referrals_count} чел.</code>\n"
        f"🛍 <b>Заработано: </b> <code>{earned_rub:.2f} ₽</code>\n"
        f"⭐️<b> Заработано звезд:</b> <code>{stars_earned}</code>\n"
        "\n🫵 <b>Свой VPN-бот</b> тоже можно открыть. Напишите администратору, если нужен запуск под ключ."
    )

    # Кнопки
    rows = []
    if contact_username:
        rows.append([{"text": "🩵 Открыть свой VPN-Бот", "url": f"https://t.me/{contact_username}", "style": "primary"}])
    rows.extend([
        [{"text": "💸 Вывести", "callback_data": "withdraw_request"}],
        [{"text": "💞 Отправить ссылку другу", "url": share_url}],
        [{"text": "⬅️ Назад в меню", "callback_data": "back_to_main"}],
    ])
    keyboard = primary({"inline_keyboard": rows})

    try:
        await callback_query.message.edit_text(text=text, reply_markup=keyboard)
    except TelegramBadRequest as e:
        logging.warning(f"Не удалось отредактировать реферальное меню: {e}")
        await callback_query.message.answer(text=text, reply_markup=keyboard)
    
    await callback_query.answer()

@router.callback_query(F.data == "withdraw_request")
async def process_withdraw(callback_query: types.CallbackQuery):
    """
    Обработка кнопки вывода средств.
    """
    user_id = callback_query.from_user.id
    stats = await get_user_stats(user_id)
    referrals_count = stats[0] if stats else 0
    
    # Условие 1: Минимум 10 рефералов
    if referrals_count < 10:
        remaining = 10 - referrals_count
        await callback_query.answer(f"Для вывода вам необходимо набрать еще {remaining} реф.", show_alert=True)
        return

    # Условие 2: Наличие активной подписки
    has_sub = await has_active_subscription(user_id)
    if not has_sub:
        await callback_query.answer("Необходимо иметь подписку на vpn для вывода!", show_alert=True)
        return

    # Если условия выполнены
    await callback_query.answer("Ваша заявка на вывод принята! Свяжитесь с администратором.", show_alert=True)
