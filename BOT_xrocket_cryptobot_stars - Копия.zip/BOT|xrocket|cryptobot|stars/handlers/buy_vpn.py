"""
Покупка VPN: выбор периода -> выбор платёжной системы.

Сами счета создаются в модулях payments/* (stars, platega, cryptobot, xrocket).
Здесь только навигация по меню.
"""

from aiogram import Router, types, F
from aiogram.exceptions import TelegramBadRequest

from functions import db
from functions.ui import primary
from payments import common

router = Router()

# Заголовок меню выбора периода (список стран и условия)
_VPN_INTRO = (
    "🌐 <b>Купить VPN</b>\n"
    "<i>Выберите период оформления подписки.</i>\n\n"
    "<b>Лимит подключений:</b> <code>5 устройств</code>\n"
    "<b>Список стран:</b> <code>30 локаций</code>\n"
    "<blockquote expandable>🇦🇪 ОАЭ • 🇱🇻 Латвия • 🇪🇪 Эстония • 🇫🇮 Финляндия\n"
    "🇸🇪 Швеция • 🇩🇪 Германия • 🇳🇱 Нидерланды • 🇫🇷 Франция\n"
    "🇨🇭 Швейцария • 🇬🇧 Великобритания • 🇺🇸 США • 🇨🇦 Канада\n"
    "🇮🇹 Италия • 🇪🇸 Испания • 🇵🇹 Португалия • 🇦🇹 Австрия\n"
    "🇨🇿 Чехия • 🇵🇱 Польша • 🇱🇹 Литва • 🇮🇪 Ирландия\n"
    "🇳🇴 Норвегия • 🇷🇴 Румыния • 🇧🇬 Болгария • 🇭🇰 Гонконг\n"
    "🇯🇵 Япония • 🇺🇦 Украина • 🇹🇷 Турция • 🇰🇿 Казахстан\n"
    "🇦🇲 Армения • 🇷🇺 Россия\n"
    "<span class=\"tg-spoiler\">✨ Список локаций постоянно расширяется</span></blockquote>\n"
)


async def _period_keyboard() -> dict:
    """Клавиатура выбора периода с актуальными ценами."""
    rows = []
    for m in common.PERIODS:
        price = await common.get_total_rub(m)
        rows.append([{"text": f"{m} мес - {price}₽", "callback_data": f"period_{m}"}])
    rows.append([{"text": "🎁 Пробный период", "callback_data": "trial_info"}])
    rows.append([{"text": "⬅️ Назад", "callback_data": "back_to_main"}])
    return primary({"inline_keyboard": rows})


@router.callback_query(F.data == "get_vpn")
async def process_get_vpn(callback_query: types.CallbackQuery):
    """Меню выбора периода."""
    kb = await _period_keyboard()
    try:
        await callback_query.message.edit_text(_VPN_INTRO, reply_markup=kb,
                                               disable_web_page_preview=True)
    except TelegramBadRequest:
        pass
    await callback_query.answer()


@router.callback_query(F.data == "trial_info")
async def process_trial_info(callback_query: types.CallbackQuery):
    """Уведомление про пробный период (по ТЗ — только всплывающее сообщение)."""
    await callback_query.answer(
        text="✅ Пригласите одного друга для получения доступа, "
             "подробнее читайте в разделе \"Реферальная система\"",
        show_alert=True,
    )


@router.callback_query(F.data.startswith("period_"))
async def process_period(callback_query: types.CallbackQuery):
    """После выбора периода — показываем способы оплаты (только включённые)."""
    try:
        months = int(callback_query.data.rsplit("_", 1)[1])
    except Exception:
        months = 1

    total_rub = await common.get_total_rub(months)

    rows = []
    if await common.method_enabled("stars"):
        stars = await common.get_stars_amount(months)
        rows.append([{"text": f"⭐ Telegram Stars ({stars} ⭐)", "callback_data": f"pay_stars_{months}"}])
    if await common.method_enabled("platega"):
        rows.append([{"text": "💳 Карта / СБП", "callback_data": f"pay_platega_{months}"}])
    if await common.method_enabled("cryptobot"):
        rows.append([{"text": "🤖 CryptoBot", "callback_data": f"pay_cryptobot_{months}"}])
    if await common.method_enabled("xrocket"):
        rows.append([{"text": "🚀 xRocket", "callback_data": f"pay_xrocket_{months}"}])
    rows.append([{"text": "⬅️ Назад", "callback_data": "get_vpn"}])

    if len(rows) == 1:  # нет ни одного включённого способа
        await callback_query.answer("❌ Оплата временно недоступна. Обратитесь к админу.",
                                    show_alert=True)
        return

    text = (
        f"<b>🔒 Подписка на VPN — {months} мес.</b>\n\n"
        f"💳 К оплате: <code>{total_rub} ₽</code>\n"
        f"📶 Трафик: <code>Безлимит</code>\n\n"
        "Выберите способ оплаты 👇"
    )
    try:
        await callback_query.message.edit_text(text, reply_markup=primary({"inline_keyboard": rows}))
    except TelegramBadRequest:
        pass
    await callback_query.answer()
