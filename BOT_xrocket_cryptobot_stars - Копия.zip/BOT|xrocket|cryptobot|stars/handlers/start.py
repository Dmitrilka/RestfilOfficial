from aiogram import Router, types, Bot
from aiogram.filters import CommandStart, CommandObject
from functions.db import add_user
from functions.ui import primary
import logging

router = Router()


def get_main_keyboard():
    """
    Возвращает инлайн-клавиатуру главного меню.
    """
    return primary({
        "inline_keyboard": [
            [
                {
                    "text": "Получить ВПН",
                    "callback_data": "get_vpn",
                    "style": "success",
                    "icon_custom_emoji_id": "5427168083074628963"
                }
            ],
            [
                {
                    "text": "Мой кабинет",
                    "callback_data": "my_profile",
                    "style": "primary",
                    "icon_custom_emoji_id": "5217822164362739968"
                }
            ],
            [
                {
                    "text": "Реферальная система",
                    "callback_data": "earnings",
                    "style": "success",
                    "icon_custom_emoji_id": "5409048419211682843"
                }
            ],
            [
                {
                    "text": "Информация",
                    "callback_data": "info",
                    "style": "primary",
                    "icon_custom_emoji_id": "5217822164362739968"
                }
            ]
        ]
    })

def get_welcome_text():
    """
    Возвращает текст приветствия.
    """
    return (
        "<b>Ваш трафик зашифрован, личные данные в безопасности. "
        "Подключайтесь в один клик — и пользуйтесь интернетом уверенно.</b>\n\n"
        "📱 <b>До 5 устройств</b> — один ключ.\n"
        "🛠 <b>Управление и инструкции</b> — в личном кабинете.\n\n"
        "💬 Нужна помощь? Напишите нам: @nexveilsupp_bot"
    )

@router.message(CommandStart())
async def cmd_start(message: types.Message, command: CommandObject, bot: Bot):
    """
    Хендлер для команды /start. Поддерживает реферальные ссылки.
    """
    args = command.args
    referred_by = None
    if args and args.isdigit():
        referred_by = int(args)
        if referred_by == message.from_user.id:
            referred_by = None

    # Регистрация пользователя в БД
    is_new_user = await add_user(
        user_id=message.from_user.id,
        username=message.from_user.username,
        full_name=message.from_user.full_name,
        referred_by=referred_by
    )

    # Если пользователь новый и пришел по ссылке, уведомляем реферера
    if is_new_user and referred_by:
        try:
            keyboard = primary({
                "inline_keyboard": [
                    [{"text": "🟢 Вывести", "callback_data": "back_to_main"}]
                ]
            })
            await bot.send_message(
                chat_id=referred_by,
                text="✅ <b>Вы пригласили пользователя! Вам начислено 15 ⭐️!</b>",
                reply_markup=keyboard
            )
        except Exception:
            pass

    # Отправляем приветствие
    await message.answer(
        text=get_welcome_text(),
        reply_markup=get_main_keyboard()
    )

@router.callback_query(lambda c: c.data == "back_to_main")
async def back_to_main_handler(callback_query: types.CallbackQuery):
    """
    Возвращает в главное меню.
    """
    await callback_query.message.edit_text(
        text=get_welcome_text(),
        reply_markup=get_main_keyboard()
    )
    await callback_query.answer()

@router.callback_query(lambda c: c.data == "earnings_from_promo")
async def process_earnings_from_promo(callback_query: types.CallbackQuery):
    """
    Обработка нажатия на кнопку "Заработать" из промо-сообщения.
    Отправляет новое сообщение с главным меню.
    """
    await callback_query.message.answer(
        text=get_welcome_text(),
        reply_markup=get_main_keyboard()
    )
    await callback_query.answer()
