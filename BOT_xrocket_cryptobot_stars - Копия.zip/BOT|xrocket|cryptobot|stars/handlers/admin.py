"""
Админ-панель (/admin). Доступ только для ADMIN_ID.

Возможности:
- Вкл/выкл авто-выдачи VPN и каждой платёжной системы
- Изменение цен (база/наценка), курса звёзд и курса USD→RUB
- Редактирование переменных .env (кроме BOT_TOKEN и ADMIN_ID)
- Рассылка сообщения всем пользователям
- Просмотр баланса API и статистики
"""

import os
import sys
import asyncio
import logging
from aiogram import Router, types, Bot, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from dotenv import set_key, dotenv_values, find_dotenv

from functions import db
from functions import api
from functions.ui import primary
from payments import common

router = Router()

ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))

# Путь к .env для редактирования переменных из админки
ENV_PATH = find_dotenv(usecwd=True) or ".env"

# Эти переменные .env редактировать из бота нельзя
ENV_EXCLUDED = {"BOT_TOKEN", "ADMIN_ID"}


def _is_secret(key: str) -> bool:
    """Секретные значения (токены/ключи) показываем в замаскированном виде."""
    return any(x in key.upper() for x in ("TOKEN", "KEY", "SECRET"))


def _mask(key: str, value: str) -> str:
    """Готовит значение для показа в кнопке (маскирует секреты, обрезает длинные)."""
    if not value:
        return "— пусто —"
    if _is_secret(key):
        return (value[:4] + "…" + value[-2:]) if len(value) > 8 else "••••"
    return value if len(value) <= 24 else value[:24] + "…"

# Человекочитаемые названия тумблеров
_TOGGLES = [
    ("vpn_enabled", "Авто-выдача VPN"),
    ("stars_enabled", "Оплата Stars"),
    ("platega_enabled", "Оплата Карта/СБП"),
    ("cryptobot_enabled", "Оплата CryptoBot"),
    ("xrocket_enabled", "Оплата xRocket"),
]

# Числовые настройки, доступные для правки
_VALUES = [
    ("stars_rate", "Курс звёзд (₽ за 1 ⭐)"),
    ("usd_rub_rate", "Курс USD→RUB"),
    ("price_1_base", "Цена 1 мес (база)"),
    ("price_3_base", "Цена 3 мес (база)"),
    ("price_6_base", "Цена 6 мес (база)"),
    ("price_12_base", "Цена 12 мес (база)"),
    ("price_1_markup", "Наценка 1 мес (%)"),
    ("price_3_markup", "Наценка 3 мес (%)"),
    ("price_6_markup", "Наценка 6 мес (%)"),
    ("price_12_markup", "Наценка 12 мес (%)"),
]


class AdminStates(StatesGroup):
    waiting_value = State()       # ждём новое значение настройки (число)
    waiting_broadcast = State()   # ждём текст рассылки
    waiting_env_value = State()   # ждём новое значение переменной .env


def _is_admin(user_id: int) -> bool:
    return ADMIN_ID and user_id == ADMIN_ID


async def _main_menu() -> dict:
    """Строит главную клавиатуру админки с текущими состояниями тумблеров."""
    rows = []
    for key, label in _TOGGLES:
        on = (await db.get_setting(key, "1")) == "1"
        mark = "🟢" if on else "🔴"
        rows.append([{"text": f"{mark} {label}", "callback_data": f"adm_toggle_{key}"}])
    rows.append([{"text": "💲 Цены и курсы", "callback_data": "adm_values"}])
    rows.append([{"text": "🔧 Настройки .env", "callback_data": "adm_env"}])
    rows.append([{"text": "📢 Рассылка", "callback_data": "adm_broadcast"}])
    rows.append([{"text": "💰 Баланс API", "callback_data": "adm_balance"},
                 {"text": "📊 Статистика", "callback_data": "adm_stats"}])
    rows.append([{"text": "♻️ Перезагрузить бота", "callback_data": "adm_restart"}])
    return primary({"inline_keyboard": rows})


@router.message(Command("admin"))
async def cmd_admin(message: types.Message):
    if not _is_admin(message.from_user.id):
        return
    await message.answer("⚙️ <b>Админ-панель</b>", reply_markup=await _main_menu())


@router.callback_query(F.data == "adm_home")
async def adm_home(callback_query: types.CallbackQuery, state: FSMContext):
    if not _is_admin(callback_query.from_user.id):
        return
    await state.clear()
    await callback_query.message.edit_text("⚙️ <b>Админ-панель</b>", reply_markup=await _main_menu())
    await callback_query.answer()


@router.callback_query(F.data.startswith("adm_toggle_"))
async def adm_toggle(callback_query: types.CallbackQuery):
    if not _is_admin(callback_query.from_user.id):
        return
    key = callback_query.data[len("adm_toggle_"):]
    current = (await db.get_setting(key, "1")) == "1"
    await db.set_setting(key, "0" if current else "1")
    await callback_query.message.edit_reply_markup(reply_markup=await _main_menu())
    await callback_query.answer("Готово")


@router.callback_query(F.data == "adm_values")
async def adm_values(callback_query: types.CallbackQuery):
    if not _is_admin(callback_query.from_user.id):
        return
    rows = []
    for key, label in _VALUES:
        val = await db.get_setting(key, "?")
        rows.append([{"text": f"{label}: {val}", "callback_data": f"adm_set_{key}"}])
    rows.append([{"text": "⬅️ Назад", "callback_data": "adm_home"}])
    await callback_query.message.edit_text(
        "💲 <b>Цены и курсы</b>\nНажмите на параметр, чтобы изменить.",
        reply_markup=primary({"inline_keyboard": rows}),
    )
    await callback_query.answer()


@router.callback_query(F.data.startswith("adm_set_"))
async def adm_set(callback_query: types.CallbackQuery, state: FSMContext):
    if not _is_admin(callback_query.from_user.id):
        return
    key = callback_query.data[len("adm_set_"):]
    await state.set_state(AdminStates.waiting_value)
    await state.update_data(key=key)
    await callback_query.message.answer(f"Введите новое значение для <code>{key}</code>:")
    await callback_query.answer()


@router.message(AdminStates.waiting_value)
async def adm_set_value(message: types.Message, state: FSMContext):
    if not _is_admin(message.from_user.id):
        return
    data = await state.get_data()
    key = data.get("key")
    value = message.text.strip()
    # Валидация: настройки числовые
    try:
        float(value)
    except ValueError:
        await message.answer("❌ Нужно число. Попробуйте ещё раз.")
        return
    await db.set_setting(key, value)
    await state.clear()
    await message.answer(f"✅ <code>{key}</code> = <b>{value}</b>",
                         reply_markup=await _main_menu())


# ─────────────────────────  Редактирование .env  ─────────────────────────

def _env_menu() -> dict:
    """Клавиатура со всеми переменными .env (кроме токена бота и ID админа)."""
    rows = []
    values = dotenv_values(ENV_PATH)
    for key, val in values.items():
        if key in ENV_EXCLUDED:
            continue
        rows.append([{"text": f"{key}: {_mask(key, val or '')}",
                      "callback_data": f"adm_envset_{key}"}])
    rows.append([{"text": "⬅️ Назад", "callback_data": "adm_home"}])
    return primary({"inline_keyboard": rows})


@router.callback_query(F.data == "adm_env")
async def adm_env(callback_query: types.CallbackQuery):
    if not _is_admin(callback_query.from_user.id):
        return
    await callback_query.message.edit_text(
        "🔧 <b>Настройки .env</b>\n"
        "Нажмите на переменную, чтобы изменить её значение.\n"
        "<i>Токен бота и ID админа изменить нельзя.</i>",
        reply_markup=_env_menu(),
    )
    await callback_query.answer()


@router.callback_query(F.data.startswith("adm_envset_"))
async def adm_envset(callback_query: types.CallbackQuery, state: FSMContext):
    if not _is_admin(callback_query.from_user.id):
        return
    key = callback_query.data[len("adm_envset_"):]
    if key in ENV_EXCLUDED:
        await callback_query.answer("Эту переменную менять нельзя.", show_alert=True)
        return
    current = dotenv_values(ENV_PATH).get(key) or "— пусто —"
    await state.set_state(AdminStates.waiting_env_value)
    await state.update_data(env_key=key)
    await callback_query.message.answer(
        f"Переменная <code>{key}</code>\n"
        f"Текущее значение: <code>{current}</code>\n\n"
        "Отправьте новое значение (или «-», чтобы очистить):"
    )
    await callback_query.answer()


@router.message(AdminStates.waiting_env_value)
async def adm_set_env_value(message: types.Message, state: FSMContext):
    if not _is_admin(message.from_user.id):
        return
    data = await state.get_data()
    key = data.get("env_key")
    if not key or key in ENV_EXCLUDED:
        await state.clear()
        await message.answer("❌ Некорректная переменная.", reply_markup=await _main_menu())
        return

    value = message.text.strip()
    if value == "-":
        value = ""

    try:
        set_key(ENV_PATH, key, value)   # запись в файл .env
        os.environ[key] = value         # обновляем текущее окружение
    except Exception as e:
        logging.error(f"Ошибка записи .env ({key}): {e}")
        await state.clear()
        await message.answer(f"❌ Не удалось сохранить: {e}",
                             reply_markup=await _main_menu())
        return

    await state.clear()
    shown = _mask(key, value)
    kb = primary({"inline_keyboard": [
        [{"text": "♻️ Перезагрузить бота (применить)", "callback_data": "adm_restart"}],
        [{"text": "⬅️ К настройкам .env", "callback_data": "adm_env"}],
    ]})
    await message.answer(
        f"✅ <code>{key}</code> = <b>{shown}</b>\n\n"
        "⚠️ Изменения токенов/ключей применяются только после <b>перезапуска бота</b>.\n"
        "Нажмите «♻️ Перезагрузить бота», чтобы применить.",
        reply_markup=kb,
    )


@router.callback_query(F.data == "adm_restart")
async def adm_restart(callback_query: types.CallbackQuery, bot: Bot):
    """Перезагружает процесс бота (перечитывает .env). Работает и под systemd."""
    if not _is_admin(callback_query.from_user.id):
        return
    await callback_query.answer("Перезагружаюсь…")
    await callback_query.message.answer("♻️ <b>Перезагружаю бота…</b>\nЧерез пару секунд снова в строю.")
    # Даём сообщению уйти и корректно закрываем сессию, затем перезапускаем процесс
    await asyncio.sleep(1)
    try:
        await bot.session.close()
    except Exception:
        pass
    os.execv(sys.executable, [sys.executable] + sys.argv)


@router.callback_query(F.data == "adm_broadcast")
async def adm_broadcast(callback_query: types.CallbackQuery, state: FSMContext):
    if not _is_admin(callback_query.from_user.id):
        return
    await state.set_state(AdminStates.waiting_broadcast)
    await callback_query.message.answer("📢 Отправьте текст рассылки (HTML поддерживается):")
    await callback_query.answer()


@router.message(AdminStates.waiting_broadcast)
async def adm_do_broadcast(message: types.Message, state: FSMContext, bot: Bot):
    if not _is_admin(message.from_user.id):
        return
    await state.clear()
    users = await db.get_all_users()
    sent = 0
    await message.answer(f"Начинаю рассылку для {len(users)} пользователей…")
    for uid in users:
        try:
            await bot.send_message(uid, message.html_text)
            sent += 1
            await asyncio.sleep(0.05)
        except Exception as e:
            logging.error(f"Рассылка: не доставлено {uid}: {e}")
    await message.answer(f"✅ Рассылка завершена. Доставлено: {sent}/{len(users)}",
                         reply_markup=await _main_menu())


@router.callback_query(F.data == "adm_balance")
async def adm_balance(callback_query: types.CallbackQuery):
    if not _is_admin(callback_query.from_user.id):
        return
    await callback_query.answer("Запрашиваю баланс…")
    res = await api.get_balance()
    if res.get("ok"):
        d = res["data"]
        text = (f"💰 <b>Баланс API</b>\n\n"
                f"Баланс: <code>{d.get('balance_rub')} ₽</code>\n"
                f"Потрачено через API: <code>{d.get('api_spent_rub')} ₽</code>")
    else:
        err = (res.get("error") or {}).get("message", "ошибка")
        text = f"❌ Не удалось получить баланс: {err}"
    await callback_query.message.answer(text)


@router.callback_query(F.data == "adm_stats")
async def adm_stats(callback_query: types.CallbackQuery):
    if not _is_admin(callback_query.from_user.id):
        return
    users = await db.get_all_users()
    pending = await db.get_pending_payments()
    await callback_query.message.answer(
        f"📊 <b>Статистика</b>\n\n"
        f"👥 Пользователей: <code>{len(users)}</code>\n"
        f"🧾 Ожидают оплаты: <code>{len(pending)}</code>"
    )
    await callback_query.answer()
