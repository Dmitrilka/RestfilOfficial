"""
Оплата через xRocket (@xRocket Pay API v1.3.1).

API base: https://pay.xrocket.tg   (заголовок Rocket-Pay-Key)
  POST /tg-invoices          — создать инвойс
  GET  /tg-invoices/{id}     — статус

Оплата в USDT (сумма конвертируется из рублей по курсу usd_rub_rate).

Flow:
  pay_xrocket_<months>  -> создаём инвойс, ссылка + кнопка проверки
  checkxr_<invoice_id>  -> проверяем статус, при оплате выдаём VPN
"""

import os
import uuid
import logging
import aiohttp
from aiogram import Router, types, Bot, F

from functions import db
from functions.ui import primary
from payments import common

router = Router()

BASE_URL = "https://pay.xrocket.tg"
TOKEN = os.getenv("XROCKET_TOKEN", "")
CURRENCY = "USDT"


def _headers() -> dict:
    return {"Content-Type": "application/json", "Rocket-Pay-Key": TOKEN}


async def create_invoice(amount_usdt: float, user_id: int) -> dict:
    """Создаёт инвойс в USDT. Возвращает {success, invoice_id, payment_url}."""
    body = {
        "amount": amount_usdt,
        "currency": CURRENCY,
        "description": f"VPN подписка (юзер {user_id})",
        "hiddenMessage": "Спасибо за оплату!",
        "expiredIn": 1800,
        "payload": f"user_{user_id}_{uuid.uuid4().hex[:8]}",
    }
    try:
        timeout = aiohttp.ClientTimeout(total=30)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(f"{BASE_URL}/tg-invoices", headers=_headers(), json=body) as r:
                if r.status in (200, 201):
                    data = (await r.json()).get("data", {})
                    return {
                        "success": True,
                        "invoice_id": str(data.get("id")),
                        "payment_url": data.get("link"),
                    }
                logging.error(f"xRocket create_invoice HTTP {r.status}: {await r.text()}")
    except Exception as e:
        logging.error(f"xRocket create_invoice: {e}")
    return {"success": False, "error": "Не удалось создать счёт"}


async def check_payment(invoice_id: str) -> bool:
    """True, если инвойс оплачен."""
    if not TOKEN:
        return False  # система не настроена — пропускаем
    try:
        timeout = aiohttp.ClientTimeout(total=30)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(f"{BASE_URL}/tg-invoices/{invoice_id}", headers=_headers()) as r:
                if r.status == 200:
                    data = (await r.json()).get("data", {})
                    status = data.get("status")
                    activations_left = data.get("activationsLeft", 1)
                    return status == "paid" or activations_left == 0
    except Exception as e:
        logging.error(f"xRocket check_payment: {e}")
    return False


@router.callback_query(F.data.startswith("pay_xrocket_"))
async def pay_xrocket(callback_query: types.CallbackQuery):
    if not await common.method_enabled("xrocket"):
        await callback_query.answer("❌ Оплата xRocket временно недоступна.", show_alert=True)
        return
    if not TOKEN:
        await callback_query.answer("❌ Не настроен токен xRocket.", show_alert=True)
        return

    try:
        months = int(callback_query.data.rsplit("_", 1)[1])
    except Exception:
        months = 1

    await callback_query.answer("Создаём счёт…")
    total_rub = await common.get_total_rub(months)
    amount_usdt = await common.get_usdt_amount(months)
    result = await create_invoice(amount_usdt, callback_query.from_user.id)

    if not result.get("success"):
        await callback_query.message.answer("❌ Не удалось создать счёт xRocket. Попробуйте другой способ.")
        return

    invoice_id = result["invoice_id"]
    await db.add_payment(callback_query.from_user.id, "xrocket", months, total_rub, invoice_id)

    text = (
        f"🚀 <b>Оплата через xRocket</b>\n\n"
        f"Сумма: <code>{amount_usdt} USDT</code> (≈ {total_rub} ₽)\nПериод: <code>{months} мес.</code>\n\n"
        "1. Нажмите «Оплатить» и оплатите в @xRocket.\n"
        "2. Затем нажмите «Проверить оплату»."
    )
    kb = primary({"inline_keyboard": [
        [{"text": "🚀 Оплатить", "url": result["payment_url"]}],
        [{"text": "✅ Проверить оплату", "callback_data": f"checkxr_{invoice_id}"}],
        [{"text": "⬅️ Назад", "callback_data": f"period_{months}"}],
    ]})
    await callback_query.message.edit_text(text, reply_markup=kb)


@router.callback_query(F.data.startswith("checkxr_"))
async def check_xrocket(callback_query: types.CallbackQuery, bot: Bot):
    invoice_id = callback_query.data.split("_", 1)[1]
    payment = await db.get_payment(invoice_id, "xrocket")
    if not payment:
        await callback_query.answer("Счёт не найден.", show_alert=True)
        return
    if payment["status"] == "paid":
        await callback_query.answer("Этот счёт уже оплачен.", show_alert=True)
        return

    await callback_query.answer("Проверяем оплату…")
    if await check_payment(invoice_id):
        if await db.mark_payment_paid(invoice_id):
            await common.issue_vpn(payment["user_id"], payment["months"], bot)
    else:
        await callback_query.answer("Оплата пока не поступила. Попробуйте позже.", show_alert=True)
