"""
Оплата через Platega.io (карты РФ / СБП, оплата в рублях).

API:
  POST {base}/transaction/process        — создать транзакцию
  GET  {base}/transaction/status/{id}    — статус
Заголовки: X-MerchantId, X-Secret

Flow:
  pay_platega_<months>   -> создаём транзакцию, показываем ссылку + кнопку проверки
  checkpg_<invoice_id>   -> проверяем статус, при оплате выдаём VPN
Плюс фоновый поллинг pending-счетов (см. main.py -> payment_poller).
"""

import os
import uuid
import logging
import aiohttp
from aiogram import Router, types, Bot, F

from functions import db
from functions.ui import primary
from payments import common

router = Router()

BASE_URL = "https://app.platega.io"
MERCHANT_ID = os.getenv("PLATEGA_MERCHANT_ID", "")
API_KEY = os.getenv("PLATEGA_API_KEY", "")
RETURN_URL = os.getenv("PLATEGA_RETURN_URL", "https://t.me")

# Приоритет методов оплаты (пробуем по очереди, если мерчанту недоступен)
_METHODS = [10, 11, 12, 9, 2, 1]


def _headers() -> dict:
    return {"Content-Type": "application/json", "X-MerchantId": MERCHANT_ID, "X-Secret": API_KEY}


async def create_invoice(amount_rub: float, user_id: int) -> dict:
    """Создаёт транзакцию Platega. Возвращает {success, payment_url, invoice_id}."""
    amount_kopecks = int(round(amount_rub * 100))
    last_error = None

    for method in _METHODS:
        transaction_id = str(uuid.uuid4())
        body = {
            "paymentMethod": method,
            "id": transaction_id,
            "paymentDetails": {"amount": amount_kopecks, "currency": "RUB"},
            "description": f"VPN подписка (юзер {user_id})",
            "return": RETURN_URL,
            "failedUrl": RETURN_URL,
            "payload": f"user_{user_id}",
        }
        try:
            timeout = aiohttp.ClientTimeout(total=30)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(f"{BASE_URL}/transaction/process",
                                        headers=_headers(), json=body) as resp:
                    if resp.status == 200:
                        result = await resp.json()
                        return {
                            "success": True,
                            "invoice_id": transaction_id,
                            "payment_url": result.get("redirect", ""),
                        }
                    error_text = await resp.text()
                    last_error = error_text
                    # Метод не поддержан мерчантом — пробуем следующий
                    if resp.status == 400 and ("paymentMethod" in error_text
                                               or "Wrong input parameters" in error_text):
                        continue
                    break
        except Exception as e:
            last_error = str(e)
            logging.error(f"Platega create_invoice: {e}")
            continue

    return {"success": False, "error": last_error or "Не удалось создать счёт"}


async def check_payment(invoice_id: str) -> bool:
    """True, если транзакция оплачена (status == success)."""
    if not (MERCHANT_ID and API_KEY):
        return False  # система не настроена — пропускаем
    try:
        timeout = aiohttp.ClientTimeout(total=30)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(f"{BASE_URL}/transaction/status/{invoice_id}",
                                   headers=_headers()) as resp:
                if resp.status == 200:
                    result = await resp.json()
                    return result.get("status") == "success"
    except Exception as e:
        logging.error(f"Platega check_payment: {e}")
    return False


@router.callback_query(F.data.startswith("pay_platega_"))
async def pay_platega(callback_query: types.CallbackQuery):
    if not await common.method_enabled("platega"):
        await callback_query.answer("❌ Оплата картой временно недоступна.", show_alert=True)
        return
    if not MERCHANT_ID or not API_KEY:
        await callback_query.answer("❌ Платёжная система не настроена (нет ключей Platega).",
                                    show_alert=True)
        return

    try:
        months = int(callback_query.data.rsplit("_", 1)[1])
    except Exception:
        months = 1

    await callback_query.answer("Создаём счёт…")
    total_rub = await common.get_total_rub(months)
    result = await create_invoice(total_rub, callback_query.from_user.id)

    if not result.get("success"):
        await callback_query.message.answer(
            f"❌ Не удалось создать счёт: {result.get('error', 'ошибка')}\nПопробуйте другой способ."
        )
        return

    invoice_id = result["invoice_id"]
    await db.add_payment(callback_query.from_user.id, "platega", months, total_rub, invoice_id)

    text = (
        f"💳 <b>Оплата картой / СБП</b>\n\n"
        f"Сумма: <code>{total_rub} ₽</code>\nПериод: <code>{months} мес.</code>\n\n"
        "1. Нажмите «Оплатить» и завершите платёж.\n"
        "2. Затем нажмите «Проверить оплату»."
    )
    kb = primary({"inline_keyboard": [
        [{"text": "💳 Оплатить", "url": result["payment_url"]}],
        [{"text": "✅ Проверить оплату", "callback_data": f"checkpg_{invoice_id}"}],
        [{"text": "⬅️ Назад", "callback_data": f"period_{months}"}],
    ]})
    await callback_query.message.edit_text(text, reply_markup=kb)


@router.callback_query(F.data.startswith("checkpg_"))
async def check_platega(callback_query: types.CallbackQuery, bot: Bot):
    invoice_id = callback_query.data.split("_", 1)[1]
    payment = await db.get_payment(invoice_id, "platega")
    if not payment:
        await callback_query.answer("Счёт не найден.", show_alert=True)
        return
    if payment["status"] == "paid":
        await callback_query.answer("Этот счёт уже оплачен.", show_alert=True)
        return

    await callback_query.answer("Проверяем оплату…")
    if await check_payment(invoice_id):
        if await db.mark_payment_paid(invoice_id):
            await common.issue_vpn(payment["user_id"], payment["months"], bot)
    else:
        await callback_query.answer("Оплата пока не поступила. Попробуйте позже.", show_alert=True)
