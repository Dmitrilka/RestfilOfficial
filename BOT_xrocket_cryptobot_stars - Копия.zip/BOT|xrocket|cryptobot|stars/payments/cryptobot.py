"""
Оплата через CryptoBot (@CryptoBot, Crypto Pay API).

API base: https://pay.crypt.bot/api   (заголовок Crypto-Pay-API-Token)
  POST /createInvoice   — создать счёт (фиат RUB, оплата любой криптой)
  POST /getInvoices     — статус

Flow:
  pay_cryptobot_<months> -> создаём инвойс, ссылка + кнопка проверки
  checkcb_<invoice_id>   -> проверяем статус, при оплате выдаём VPN
"""

import os
import logging
import aiohttp
from aiogram import Router, types, Bot, F

from functions import db
from functions.ui import primary
from payments import common

router = Router()

BASE_URL = "https://pay.crypt.bot/api"
TOKEN = os.getenv("CRYPTOBOT_TOKEN", "")
ACCEPTED_ASSETS = "USDT,TON,TRX,BTC"


def _headers() -> dict:
    return {"Crypto-Pay-API-Token": TOKEN, "Content-Type": "application/json"}


async def _api(method: str, endpoint: str, data: dict = None) -> dict:
    try:
        timeout = aiohttp.ClientTimeout(total=30)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            if method == "GET":
                r = await session.get(f"{BASE_URL}{endpoint}", headers=_headers())
            else:
                r = await session.post(f"{BASE_URL}{endpoint}", headers=_headers(), json=data)
            async with r:
                # content_type=None — не падаем, если сервер вернул не JSON (напр. HTML при неверном токене)
                try:
                    return await r.json(content_type=None)
                except Exception:
                    text = await r.text()
                    return {"ok": False, "error": f"HTTP {r.status}: {text[:120]}"}
    except Exception as e:
        logging.error(f"CryptoBot API {endpoint}: {e}")
        return {"ok": False, "error": str(e)}


async def create_invoice(amount_rub: float, user_id: int) -> dict:
    """Создаёт фиатный (RUB) инвойс. Возвращает {success, invoice_id, payment_url}."""
    result = await _api("POST", "/createInvoice", {
        "currency_type": "fiat",
        "fiat": "RUB",
        "amount": str(amount_rub),
        "accepted_assets": ACCEPTED_ASSETS,
        "description": f"VPN подписка (юзер {user_id})",
        "payload": str(user_id),
        "expires_in": 1800,
    })
    if result.get("ok"):
        inv = result["result"]
        return {
            "success": True,
            "invoice_id": str(inv.get("invoice_id")),
            "payment_url": inv.get("pay_url") or inv.get("bot_invoice_url"),
        }
    return {"success": False, "error": result.get("error", "ошибка")}


async def check_payment(invoice_id: str) -> bool:
    """True, если инвойс оплачен (status == paid)."""
    if not TOKEN:
        return False  # система не настроена — пропускаем
    result = await _api("POST", "/getInvoices", {"invoice_ids": invoice_id})
    if result.get("ok"):
        items = result.get("result", {}).get("items", [])
        if items:
            return items[0].get("status") == "paid"
    return False


@router.callback_query(F.data.startswith("pay_cryptobot_"))
async def pay_cryptobot(callback_query: types.CallbackQuery):
    if not await common.method_enabled("cryptobot"):
        await callback_query.answer("❌ Оплата CryptoBot временно недоступна.", show_alert=True)
        return
    if not TOKEN:
        await callback_query.answer("❌ Не настроен токен CryptoBot.", show_alert=True)
        return

    try:
        months = int(callback_query.data.rsplit("_", 1)[1])
    except Exception:
        months = 1

    await callback_query.answer("Создаём счёт…")
    total_rub = await common.get_total_rub(months)
    result = await create_invoice(total_rub, callback_query.from_user.id)

    if not result.get("success"):
        await callback_query.message.answer("❌ Не удалось создать счёт CryptoBot. Попробуйте другой способ.")
        return

    invoice_id = result["invoice_id"]
    await db.add_payment(callback_query.from_user.id, "cryptobot", months, total_rub, invoice_id)

    text = (
        f"🤖 <b>Оплата через CryptoBot</b>\n\n"
        f"Сумма: <code>{total_rub} ₽</code> (крипто)\nПериод: <code>{months} мес.</code>\n\n"
        "1. Нажмите «Оплатить» и оплатите в @CryptoBot.\n"
        "2. Затем нажмите «Проверить оплату»."
    )
    kb = primary({"inline_keyboard": [
        [{"text": "🤖 Оплатить", "url": result["payment_url"]}],
        [{"text": "✅ Проверить оплату", "callback_data": f"checkcb_{invoice_id}"}],
        [{"text": "⬅️ Назад", "callback_data": f"period_{months}"}],
    ]})
    await callback_query.message.edit_text(text, reply_markup=kb)


@router.callback_query(F.data.startswith("checkcb_"))
async def check_cryptobot(callback_query: types.CallbackQuery, bot: Bot):
    invoice_id = callback_query.data.split("_", 1)[1]
    payment = await db.get_payment(invoice_id, "cryptobot")
    if not payment:
        await callback_query.answer("Счёт не найден.", show_alert=True)
        return
    if payment["status"] == "paid":
        await callback_query.answer("Этот счёт уже оплачен.", show_alert=True)
        return

    await callback_query.answer("Проверяем оплату…")
    if await check_payment(invoice_id):
        if await db.mark_payment_paid(invoice_id):
            await common.issue_vpn(payment["user_id"], payment["months"], bot)
    else:
        await callback_query.answer("Оплата пока не поступила. Попробуйте позже.", show_alert=True)
