"""
Общая логика платежей: расчёт цен и выдача VPN после успешной оплаты
(любым способом — Stars, Platega, CryptoBot, xRocket).
"""

import os
import logging
from functions import db
from functions import api
from functions.ui import primary

router = None  # у этого модуля роутера нет — только хелперы

ADMIN_ID = os.getenv("ADMIN_ID")

# Доступные периоды подписки (месяцы)
PERIODS = [1, 3, 6, 12]

# Процент реферального вознаграждения с покупки приглашённого
REFERRAL_PERCENT = 50


async def get_total_rub(months: int) -> int:
    """Итоговая цена для пользователя = базовая цена + наценка (из настроек)."""
    base = float(await db.get_setting(f"price_{months}_base", "200"))
    markup = float(await db.get_setting(f"price_{months}_markup", "100"))
    return int(base + (base * markup / 100))


async def get_stars_amount(months: int) -> int:
    """Цена в звёздах Telegram (XTR) исходя из курса stars_rate."""
    total_rub = await get_total_rub(months)
    rate = float(await db.get_setting("stars_rate", "2"))
    return max(1, int(total_rub / rate))


async def get_usdt_amount(months: int) -> float:
    """Цена в USDT для xRocket исходя из курса usd_rub_rate."""
    total_rub = await get_total_rub(months)
    rate = float(await db.get_setting("usd_rub_rate", "100"))
    return round(total_rub / rate, 2)


async def method_enabled(method: str) -> bool:
    """Проверяет тумблер платёжной системы в настройках."""
    return (await db.get_setting(f"{method}_enabled", "1")) == "1"


async def issue_vpn(user_id: int, months: int, bot) -> bool:
    """
    Выдаёт/продлевает VPN через API после успешной оплаты и уведомляет
    пользователя. Возвращает True при успехе.

    - Если у пользователя уже есть активная подписка — продлеваем (renew).
    - Иначе покупаем новую (buy).
    - Если авто-выдача выключена админом (vpn_enabled=0) — просим написать в
      поддержку (оплата при этом уже прошла).
    """
    # Авто-выдача отключена админом
    if not await db.is_vpn_enabled():
        try:
            await bot.send_message(
                user_id,
                "⚠️ <b>Оплата прошла, но выдача ключа временно недоступна.</b>\n\n"
                "Обратитесь в поддержку — мы выдадим доступ вручную.",
            )
            if ADMIN_ID:
                await bot.send_message(
                    int(ADMIN_ID),
                    f"❗️ Пользователь <code>{user_id}</code> оплатил {months} мес., "
                    f"но авто-выдача выключена. Выдайте вручную.",
                )
        except Exception:
            pass
        return False

    active = await db.get_active_subscription(user_id)
    try:
        if active and active.get("uuid"):
            response = await api.renew_vpn(active["uuid"], months)
            is_renew = True
        else:
            response = await api.buy_vpn(months)
            is_renew = False
    except Exception as e:
        logging.error(f"API исключение при выдаче VPN {user_id}: {e}")
        response = {"ok": False, "error": {"message": str(e)}}
        is_renew = bool(active)

    if not response.get("ok"):
        err = (response.get("error") or {}).get("message", "неизвестная ошибка")
        logging.error(f"Ошибка выдачи VPN юзеру {user_id}: {response}")
        try:
            await bot.send_message(
                user_id,
                "⚠️ <b>Оплата прошла, но не удалось выдать ключ автоматически.</b>\n\n"
                "Обратитесь в поддержку — мы всё исправим.",
            )
            if ADMIN_ID:
                await bot.send_message(
                    int(ADMIN_ID),
                    f"❗️ Ошибка выдачи VPN юзеру <code>{user_id}</code>: {err}",
                )
        except Exception:
            pass
        return False

    data = response["data"]
    uuid = data.get("uuid") or (active or {}).get("uuid")
    sub_url = data.get("subscriptionUrl")
    expire_at = data.get("expireAt")
    expire_date = data.get("expireAt_date")

    # Сохраняем в БД
    if is_renew and uuid:
        await db.update_vpn_subscription(uuid, expire_at, sub_url, expire_date)
    else:
        await db.add_vpn_subscription(user_id, uuid, expire_at, sub_url, expire_date)

    # Уведомляем пользователя
    title = "🔄 <b>Подписка продлена!</b>" if is_renew else "✅ <b>VPN активирован!</b>"
    text = (
        f"{title}\n\n"
        f"📅 <b>Действует до:</b> <code>{expire_date}</code>\n\n"
        f"🔗 <b>Ссылка для подключения:</b>\n<code>{sub_url}</code>\n\n"
        "📌 Откройте ссылку в приложении (Happ / v2rayTun / любой поддерживающий подписки)."
    )
    back_kb = primary({"inline_keyboard": [[{"text": "⬅️ В меню", "callback_data": "back_to_main"}]]})
    try:
        await bot.send_message(user_id, text, reply_markup=back_kb)
    except Exception as e:
        logging.error(f"Не удалось уведомить {user_id} о выдаче VPN: {e}")

    # Реферальное вознаграждение пригласившему (50% от цены)
    try:
        referrer = await db.get_referrer(user_id)
        if referrer:
            total_rub = await get_total_rub(months)
            reward = round(total_rub * REFERRAL_PERCENT / 100, 2)
            await db.add_referral_earning(referrer, reward)
            try:
                await bot.send_message(
                    referrer,
                    f"💸 <b>Ваш реферал оплатил VPN!</b>\nНачислено: <code>{reward} ₽</code>",
                )
            except Exception:
                pass
    except Exception as e:
        logging.error(f"Ошибка начисления реферального бонуса: {e}")

    # Лог админу
    if ADMIN_ID:
        try:
            await bot.send_message(
                int(ADMIN_ID),
                f"💰 Оплата: юзер <code>{user_id}</code>, {months} мес. "
                f"({'продление' if is_renew else 'новая'}).",
            )
        except Exception:
            pass

    return True
