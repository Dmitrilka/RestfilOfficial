"""
Оплата через Telegram Stars (XTR).

Flow:
  callback pay_stars_<months>  -> отправляем инвойс в звёздах
  pre_checkout_query           -> подтверждаем
  message(F.successful_payment)-> выдаём VPN
"""

import logging
from aiogram import Router, types, Bot, F
from aiogram.types import LabeledPrice

from functions import db
from payments import common

router = Router()


@router.callback_query(F.data.startswith("pay_stars_"))
async def pay_stars(callback_query: types.CallbackQuery):
    """Отправляет инвойс на оплату в Telegram Stars."""
    if not await common.method_enabled("stars"):
        await callback_query.answer("❌ Оплата через Stars временно недоступна.", show_alert=True)
        return

    try:
        months = int(callback_query.data.rsplit("_", 1)[1])
    except Exception:
        months = 1

    stars_amount = await common.get_stars_amount(months)
    await callback_query.answer("Генерируем счёт…")

    await callback_query.message.answer_invoice(
        title=f"VPN на {months} мес.",
        description=f"Доступ к VPN на {months} мес. Оплата в Telegram Stars.",
        payload=f"vpn_{months}",
        provider_token="",       # для XTR токен провайдера не нужен
        currency="XTR",
        prices=[LabeledPrice(label=f"VPN {months} мес.", amount=stars_amount)],
    )


@router.pre_checkout_query()
async def pre_checkout(pre_checkout_query: types.PreCheckoutQuery):
    """Подтверждаем готовность принять платёж."""
    await pre_checkout_query.answer(ok=True)


@router.message(F.successful_payment)
async def successful_payment(message: types.Message, bot: Bot):
    """После успешной оплаты звёздами — выдаём VPN."""
    payload = message.successful_payment.invoice_payload or ""
    try:
        months = int(payload.split("_")[1])
    except Exception:
        months = 1

    logging.info(f"Успешная оплата Stars: юзер {message.from_user.id}, {months} мес.")
    await common.issue_vpn(message.from_user.id, months, bot)
