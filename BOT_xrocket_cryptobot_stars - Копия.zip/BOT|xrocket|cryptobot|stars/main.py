import asyncio
import logging
import os
from dotenv import load_dotenv

# Загружаем переменные окружения в самом начале
load_dotenv()

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties

from handlers import start, buy_vpn, profile, admin, info, earnings
from payments import stars, platega, cryptobot, xrocket, common
from functions.db import init_db, get_pending_payments, mark_payment_paid


async def payment_poller(bot: Bot):
    """
    Фоновая проверка неоплаченных счетов Platega / CryptoBot / xRocket.
    Telegram Stars обрабатываются нативно и здесь не проверяются.
    """
    checkers = {
        "platega": platega.check_payment,
        "cryptobot": cryptobot.check_payment,
        "xrocket": xrocket.check_payment,
    }
    while True:
        try:
            for payment in await get_pending_payments():
                checker = checkers.get(payment["method"])
                if not checker:
                    continue
                try:
                    if await checker(payment["invoice_id"]):
                        # Атомарно помечаем оплаченным (защита от двойной выдачи)
                        if await mark_payment_paid(payment["invoice_id"]):
                            await common.issue_vpn(payment["user_id"], payment["months"], bot)
                except Exception as e:
                    logging.error(f"Поллинг {payment['method']}/{payment['invoice_id']}: {e}")
        except Exception as e:
            logging.error(f"Ошибка в payment_poller: {e}")
        await asyncio.sleep(30)


async def on_startup(bot: Bot):
    """Действия при запуске: инициализация БД и запуск фонового поллинга."""
    await init_db()
    asyncio.create_task(payment_poller(bot))
    logging.info("Бот запущен, фоновый поллинг оплат активен.")


async def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
    )

    token = os.getenv("BOT_TOKEN")
    if not token:
        raise RuntimeError("BOT_TOKEN не задан в .env")

    bot = Bot(token=token, default=DefaultBotProperties(parse_mode="HTML"))
    dp = Dispatcher()

    # Хендлеры интерфейса
    dp.include_router(start.router)
    dp.include_router(buy_vpn.router)
    dp.include_router(profile.router)
    dp.include_router(admin.router)
    dp.include_router(info.router)
    dp.include_router(earnings.router)

    # Платёжные роутеры
    dp.include_router(stars.router)
    dp.include_router(platega.router)
    dp.include_router(cryptobot.router)
    dp.include_router(xrocket.router)

    await on_startup(bot)

    try:
        await dp.start_polling(bot)
    finally:
        await bot.session.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
